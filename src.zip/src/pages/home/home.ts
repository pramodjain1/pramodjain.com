import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { trigger,style,transition,animate,keyframes,query,stagger,state } from '@angular/animations';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html',
  animations :[
    trigger('popOverState', [
      state('show', style({
        visibility : 'visible',
        'max-height' : '100%'
      })),
      state('hide',   style({
        'max-height' : '0px'
      })),
      transition('show => hide', animate('500ms ease-out')),
      transition('hide => show', animate('500ms ease-in'))
    ])
  ]
})
export class HomePage {

  show = false;
  constructor(public navCtrl: NavController) {

  }

  get stateName() {
    return this.show ? 'show' : 'hide'
  }
  toggle() {
    this.show = !this.show;
  }


}
